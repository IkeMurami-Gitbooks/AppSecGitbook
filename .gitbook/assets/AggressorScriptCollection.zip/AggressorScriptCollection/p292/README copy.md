# Phant0m_cobaltstrike
Aggressor script to integrate Phant0m with Cobalt Strike

Expects to find Powershell Script in "disableeventvwr/Invoke-Phant0m.ps1" - edit as appropriate to where you store file.
