# DDEAutoCS
A cobaltstrike script that integrates DDEAuto Attacks (launches a staged powershell CS beacon)

- Author: Matt Ettelaie (github.com/p292) (https://uk.linkedin.com/in/mettelaie) 
- KPMG UK Cyber Defence Services - kpmg.co.uk/cyber
- Credits to @armitagehacker for the original template script
- Credits to @sensepost - https://sensepost.com/blog/2017/macro-less-code-exec-in-msword/

# Readme Things
This is not massively stealthy as far as CS scripts go anything like that at the moment, more of a proof of concept, and for having a play. Customise as you see fit to your needs.

As an example for the word errors pop up I've used a fake 'Symantec Decryption Module' load error - customise for what you think you need for your red-teaming.

# Pictures (worth 1000 words)
Workflow in Cobaltstrike:
![alt text](https://raw.githubusercontent.com/p292/DDEAutoCS/master/img/Git.png)



What users see in word (rememeber this only works when protected mode has been enabled...)
![alt text](https://raw.githubusercontent.com/p292/DDEAutoCS/master/img/Git2.png)

Thanks!
Matt
