# Aggressor Scripts

Collection of Aggressor Scripts for Cobalt Strike

## Basic Usage
If you clone the whole repo, you only need to load `loader.cna` into the Script Manager.  Child modules will be automatically included.
If you only want to use particular modules, e.g. `elevate`, then load `elevate\elevate.cna` as desired.

## Modules

### Elevate
Exploit local priviledge escalation vulnerabilities

### Persistence
Install persistence mechanisms on compromised hosts