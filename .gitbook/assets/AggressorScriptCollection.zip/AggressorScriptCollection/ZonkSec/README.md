# persistence-aggressor-script

* Modified to use encoded powershell commands and allow selection of persistence in multiple listener scenarios (local or foreign)
* Added linkinfo.dll explorer.exe DLL hijack option

http://zonksec.com/blog/persistence-aggressor-script/
