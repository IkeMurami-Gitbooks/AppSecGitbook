Contains a bunch of CobaltStrike Aggressor Scripts

Ping: Converts an IP address to Hex equivalent and uses ping command. Prevents IR regex for IP addresses.

Auto-prepenv: Automatically preps the environment on initial beacon

VNC-psh: Runs a VNC server on the target

Credleak: Starts a proxy server on localhost 8080 and connects to it to leak the NetNTLMv2 hash.

