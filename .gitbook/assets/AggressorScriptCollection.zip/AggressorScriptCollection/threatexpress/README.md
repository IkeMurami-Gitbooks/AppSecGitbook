# Cobalt Strike Aggressor Scripts

Collection of Cobalt Strike Aggressor Scripts