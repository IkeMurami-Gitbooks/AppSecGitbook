# D3 Notes

Arrows and Labels

http://bl.ocks.org/fancellu/2c782394602a93921faff74e594d1bb1
https://gist.github.com/satomacoto/3384995


D3 force simulation, curved edges and hover interaction (Data: Twitter mentions between members of the Welsh Assembly)

https://bl.ocks.org/martinjc/7aa53c7bf3e411238ac8aef280bd6581


Tooltips

http://www.d3noob.org/2013/01/adding-tooltips-to-d3js-graph.html

Font Awesome

https://fontawesome.com/cheatsheet